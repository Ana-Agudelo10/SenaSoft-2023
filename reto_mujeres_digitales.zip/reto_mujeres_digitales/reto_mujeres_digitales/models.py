from django.db import models

class Player(models.Model):
    name = models.CharField(max_length=100) #nombre jugador
    number = models.PositiveIntegerField() #numero del jugador
    room = models.CharField(max_length=6) #codigo sala a la cual pertenece
    
    def __str__(self):
        return f"{self.name} - Jugador {self.number}"

class Carta(models.Model):
    nombre = models.CharField(max_length=100)
    nivel = models.IntegerField()
    alcance = models.FloatField()
    
class Sala(models.Model):
    room_pin = models.CharField(max_length=6)
    jugadores = models.ManyToManyField(Player)
    cartas = models.ManyToManyField(Carta)
    mode = models.CharField(max_length=100)
    time = models.IntegerField()    