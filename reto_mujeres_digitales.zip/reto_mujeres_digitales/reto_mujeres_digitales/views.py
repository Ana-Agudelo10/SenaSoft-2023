from django.shortcuts import render
from django.http import JsonResponse
import random
import string
from django.views import View
from .models import Player, Carta, Sala

def generate_room_pin():
    characters = string.ascii_letters + string.digits
    return ''.join(random.choices(characters, k=6))

rooms = {}

def home(request):
    return render(request, 'index.html')

class CreateRoomView(View):
    template_name = 'crear_sala.html'

    def get(self, request):
        return render(request, self.template_name, {'room_pin': None})

    def post(self, request):
        player_name = request.POST.get('nombre_jugador')
        player_number = int(request.POST.get('numero_jugador'))
        pin = generate_room_pin()

        player = Player(name=player_name, number=player_number, room=pin)
        player.save()
        
        sala = Sala(room_pin=pin, mode='', time=0)
        sala.save()
        sala.players.add(player)

        return JsonResponse({'pin': pin})

def create_room(request):
    if request.method == 'POST':
        player_name = request.POST.get('nombre_jugador')
        player_number = int(request.POST.get('numero_jugador'))
        pin = generate_room_pin()
        player = Player(name=player_name, number=player_number, room=pin)
        player.save()
        rooms[pin] = {
            'players': [{'name': player_name, 'number': player_number, 'is_player1': True}],
            'cards': [],  # cartas para cada partida
            'mode': '',   # cartas completas
            'time': 0     # limite tiempo
        }
        return JsonResponse({'pin': pin})

    return render(request, 'crear_sala.html', {'room_pin': None})

def join_room(request):
    if request.method == 'POST':
        player_name = request.POST.get('nombre_jugador')
        player_number = int(request.POST.get('numero_jugador'))
        pin = request.POST.get('pin')
        if pin in rooms:
            rooms[pin]['players'].append({'name': player_name, 'number': player_number})
            player = Player(name=player_name, number=player_number, room=pin)
            player.save()
            return render(request, 'unirse_sala.html', {'message': 'Exitoso'})
        else:
            return render(request, 'unirse_sala.html', {'message': 'Sala no encontrada'})
    return render(request, 'unirse_sala.html')

def room_waiting(request, pin):
    if pin in rooms:
        room_info = rooms[pin]
        players_in_room = Player.objects.filter(room=pin) 
        return render(request, 'sala_espera.html', {'pin': pin, 'room_info': room_info, 'players_in_room': players_in_room})
    else:
        return JsonResponse({'message': 'Sala no encontrada'})
    
def select_game_method(request, pin):
    if pin in rooms:
        room_info = rooms[pin]
        if request.method == 'POST':
            method = request.POST.get('method')
            room_info['mode'] = method
        return render(request, 'metodologia.html', {'pin': pin, 'room_info': room_info})
    else:
        return JsonResponse({'message': 'Sala no encontrada'})
    

def sala_juego(request, room_pin):
    # Obtener todas las cartas disponibles de la base de datos
    cartas_disponibles = Carta.objects.all()

    context = {
        'cartas_disponibles': cartas_disponibles,
    }

    return render(request, 'sala_juego.html', context)  
